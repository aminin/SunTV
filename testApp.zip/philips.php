<?php
header('Content-Type: application/ce-html+xml; charset=UTF-8');
readfile(__DIR__ . '/index.html');

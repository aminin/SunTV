(function () {
  "use strict";

   _.templateSettings.interpolate = /\{\{([\s\S]+?)\}\}/g;

  var videoItemHtml = _.template('<li data-url="{{url}}" data-type="{{type}}" role="presentation" class="video-item nav-item"><a href="#">{{num}}. {{title}}</a></li>');


  window.App = {
    currentScene: null,
    scenes: {
      menu:{
        _inited:false,
        init:function(){
          this.$el = $('.js-scene-menu');
        },
        show: function () {
          if (!this._inited) {
            this.init();
          }

          this.$el.show();
          $('.bg').show();
          $('#smart_player').hide();
        },
        hide: function () {
          this.$el.hide();
          $('#smart_player').show();
        }
      },
      stream:{
        _inited:false,
        init: function () {
          this.$el = $('.js-scene-stream');

          this.$el.on('click', '.video-item', this.onItemClick);

          this.renderItems(App.videos);

          this._inited = true;
        },

        show: function () {
          if (!this._inited) {
            this.init();
          }

          this.$el.show();
        },

        hide: function () {
          this.$el.hide();
        },

        // handler for click event
        onItemClick: function (e) {
          var url = e.currentTarget.getAttribute('data-url');
          Player.play({
            url: url,
            type: e.currentTarget.getAttribute('data-type')
          });
        },

        // showing items from videos.js
        renderItems: function (items) {
          var html = '';

           // console.log(items, itemHtml.toString())
          for ( var i = 0, len = items.length; i < len; i++ ) {
            items[i].num = i+1;
            html += videoItemHtml(items[i]);
          }

          // this.$el
          //   .empty()

          this.$el.find('.nav-pills').eq(1).html(html);
        }
      },
      vod:{
        _inited:false,
        init:function(){
          this.$el = $('.js-scene-vod');
        },
        show: function () {
          if (!this._inited) {
            this.init();
          }

          this.$el.show();
        },
        hide: function () {
          this.$el.hide();
        }
      }

    },
    isShown: true,

    initialize: function () {
      this.$wrap = $('.wrap');

      //$$legend.show();

      this.setEvents();

      // start navigation
      $$nav.on();

      this.showContent('menu');
    },

    setEvents: function () {
      var self = this;
      var $bg = $('.bg');

      // click on menu item
      $('.menu').on('click', '.menu-item', function ( e ) {
        var scene = e.currentTarget.getAttribute('data-content');
        self.showContent(scene);
      });

      $(document.body).on({
        // on keyboard 'd' by default
        // 'nav_key:blue': _.bind(this.toggleView, this),

        // remote events
        'nav_key:stop': function () {
          Player.stop();
        },
        'nav_key:pause': function () {
          Player.togglePause();
        },
        'nav_key:exit': function(){
          SB.exit();
        }
      });

      $('ul.roller').delegate('li.nav-item', 'nav_focus', function(a,b,c) {
          if(a.target.getBoundingClientRect().bottom > 720){
            var top = ($(a.target).parent('ul').find('li').index(a.target) - 7) * 40;
            $(a.target).parent('ul').css('top',(-top+1)+'px');
          }
          if(a.target.getBoundingClientRect().top < 398){
            var top = ($(a.target).parent('ul').find('li').index(a.target) ) * 40;
            $(a.target).parent('ul').css('top',(-top+1)+'px');
          }
        })
      // $('ul').delegate('li.nav-item', 'nav_blur', function(a,b,c) {
      //     console.log(a,b,c);
      // })

      // toggling background when player start/stop
      Player.on('ready', function () {
        $bg.hide();
        $$log('player ready');
      });
      Player.on('stop', function () {
        $bg.show();
        $$log('player stop');
      });


    },

    // toggleView: function () {
    //   if (this.isShown) {
    //     this.$wrap.hide();
    //     $$legend.hide();
    //   } else {
    //     this.$wrap.show();
    //     $$legend.show();
    //   }
    //   this.isShown = !this.isShown;
    // },

    showContent: function ( scene ) {
      var cur = this.currentScene,
        newScene = this.scenes[scene];

      if ( cur !== newScene ) {
        if ( !newScene ) {
          $$error('Scene ' + scene + ' doesn\'t exist');
        } else {
          if ( cur ) {
            cur.hide();
          }
          newScene.show();
          this.currentScene = newScene;
        }
      }
    }
  };

  // main app initialize when smartbox ready
  SB(_.bind(App.initialize, App));
})();
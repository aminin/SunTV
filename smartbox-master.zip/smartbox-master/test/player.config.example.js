var Config={
    trailer: 'path to short video',
    trailerHeight: 180,
    trailerWidth: 320,
    trailerDuration: '02:11',
    movie: 'path to long video',
    hls: 'path to stream'
}

var Config={
    trailer: 'http://ua-cnt.smart-kino.com//trailers/russkiy_reportazh/korporatsiya_svyatye_motory.mp4',
    trailerWidth: 640,
    trailerHeight: 360,
    trailerDuration: '00:31',
    movie: 'https://archive.org/download/ElephantsDream/ed_1024_512kb.mp4',
    movieAudioTracksLength: 2,
    hls: 'http://phone.pik-tv.com/live/mp4:piktv3pik3tv/playlist.m3u8'
}